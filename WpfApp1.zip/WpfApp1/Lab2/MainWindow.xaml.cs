﻿/*using System;
using System.Collections.Generic;
using System.Numerics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Lab2
{
    // --- DATENSTRUKTUREN FÜR RAY TRACING ---

    /// <summary>
    /// Repräsentiert einen Strahl im 3D-Raum.
    /// </summary>
    public struct Ray
    {
        public Vector3 Origin;
        public Vector3 Direction;
    }

    /// <summary>
    /// Definiert die Oberflächeneigenschaften eines Objekts.
    /// Vorerst nur die Farbe (im linearen RGB-Raum).
    /// </summary>
    public struct Material
    {
        public Vector3 Color;
    }

    /// <summary>
    /// Speichert Informationen über einen Ray-Objekt-Schnittpunkt.
    /// </summary>
    public struct HitInfo
    {
        public bool DidHit;
        public float Distance;
        public Vector3 HitPoint;
        public Vector3 Normal;
        public Material Material;
    }

    /// <summary>
    /// Repräsentiert eine Kugel in der 3D-Szene.
    /// </summary>
    public class Sphere
    {
        public Vector3 Center;
        public float Radius;
        public Material Material;

        /// <summary>
        /// Berechnet den Schnittpunkt eines Strahls mit dieser Kugel.
        /// </summary>
        /// <param name="ray">Der Strahl, der getestet wird.</param>
        /// <returns>HitInfo mit den Details des Treffers.</returns>
        public HitInfo Intersect(Ray ray)
        {
            Vector3 oc = ray.Origin - Center;
            float a = Vector3.Dot(ray.Direction, ray.Direction);                         
            float b = 2.0f * Vector3.Dot(oc, ray.Direction);
            float c = Vector3.Dot(oc, oc) - Radius * Radius;
            float discriminant = b * b - 4 * a * c;

            if (discriminant < 0)
            {
                return new HitInfo { DidHit = false }; // Kein Treffer
            }
            
            float t = (-b - MathF.Sqrt(discriminant)) / (2.0f * a);
            // Wir wollen nur Treffer, die vor der Kamera liegen (t > 0)
            if (t < 0.001f) {
                t = (-b + MathF.Sqrt(discriminant)) / (2.0f * a);
                if (t < 0.001f) return new HitInfo { DidHit = false };
            }

            Vector3 hitPoint = ray.Origin + t * ray.Direction;
            return new HitInfo
            {
                DidHit = true,
                Distance = t,
                HitPoint = hitPoint,
                Normal = Vector3.Normalize(hitPoint - Center),
                Material = this.Material
            };
        }
    }

    /// <summary>
    /// Enthält alle Objekte der Szene.
    /// </summary>
    public class Scene
    {
        public List<Sphere> Spheres = new List<Sphere>();
    }


    public partial class MainWindow : Window
    {
        const int W = 512, H = 512;
        private WriteableBitmap _wb;

        public MainWindow()
        {
            InitializeComponent();
            Image canvasImage = new Image();
            this.Content = canvasImage;
            _wb = new WriteableBitmap(W, H, 96, 96, PixelFormats.Bgra32, null);
            canvasImage.Source = _wb;

            // Starte den Rendering-Prozess
            RenderScene();
        }
        
        /// <summary>
        /// Die Hauptfunktion, die die Szene aufbaut und rendert.
        /// </summary>
        void RenderScene()
        {
            // 1. Szene definieren (ähnlich deiner Vorlage)
            // Hinweis: Die Farben sind < 1.0, wie in deinem Bild empfohlen (~80% Intensität)
            var scene = new Scene();
            scene.Spheres.Add(new Sphere { Center = new Vector3(-1001, 0, 0), Radius = 1000, Material = new Material { Color = new Vector3(0.8f, 0.1f, 0.1f) } }); // Linke Wand (Rot)
            scene.Spheres.Add(new Sphere { Center = new Vector3(1001, 0, 0), Radius = 1000, Material = new Material { Color = new Vector3(0.1f, 0.1f, 0.8f) } }); // Rechte Wand (Blau)
            scene.Spheres.Add(new Sphere { Center = new Vector3(0, 1001, 0), Radius = 1000, Material = new Material { Color = new Vector3(0.8f, 0.8f, 0.8f) } }); // Decke (Grau)
            scene.Spheres.Add(new Sphere { Center = new Vector3(0, -1001, 0), Radius = 1000, Material = new Material { Color = new Vector3(0.6f, 0.6f, 0.6f) } }); // Boden (Grau)
            scene.Spheres.Add(new Sphere { Center = new Vector3(0, 0, 1001), Radius = 1000, Material = new Material { Color = new Vector3(0.6f, 0.6f, 0.6f) } }); // Rückwand (Grau)

            scene.Spheres.Add(new Sphere { Center = new Vector3(-0.6f, -0.7f, -0.6f), Radius = 0.3f, Material = new Material { Color = new Vector3(0.9f, 0.9f, 0.1f) } }); // Gelbe Kugel
            scene.Spheres.Add(new Sphere { Center = new Vector3(0.3f, -0.4f, 0.3f), Radius = 0.6f, Material = new Material { Color = new Vector3(0.1f, 0.9f, 0.9f) } }); // Cyan Kugel
            
            // 2. Kamera definieren
            /*Vector3 eye = new Vector3(0, 0, -4);#1#
            Vector3 eye = new Vector3(-0.9f, -0.5f, 0.9f);
            /*Vector3 lookAt = new Vector3(0, 0, 6);#1#
            Vector3 lookAt = new Vector3(0, 0, 0);
            /*float fov = 36.0f;#1#
            float fov = 110.0f;
            Vector3 backgroundColor = new Vector3(0,0,0); // Schwarzer Hintergrund

            int stride = _wb.BackBufferStride;
            byte[] pixels = new byte[stride * H];
            
            // Kamera-Setup für die Strahlenberechnung
            float aspectRatio = (float)W / H;
            float fovRad = MathF.PI / 180.0f * fov;
            float viewportHeight = 2.0f * MathF.Tan(fovRad / 2.0f);
            float viewportWidth = viewportHeight * aspectRatio;

            Vector3 forward = Vector3.Normalize(lookAt - eye);
            Vector3 right = Vector3.Normalize(Vector3.Cross(new Vector3(0, 1, 0), forward));
            Vector3 up = Vector3.Cross(forward, right);

            // 3. Durch jeden Pixel iterieren
            for (int y = 0; y < H; y++)
            {
                for (int x = 0; x < W; x++)
                {
                    // a. Strahl für diesen Pixel erstellen (CreateEyeRay)
                    float u = (x / (float)(W - 1)) * 2.0f - 1.0f; // von -1 bis 1
                    float v = ((H - 1 - y) / (float)(H - 1)) * 2.0f - 1.0f; // von -1 bis 1 (y umkehren)
                    
                    Ray ray = new Ray
                    {
                        Origin = eye,
                        Direction = Vector3.Normalize(forward + u * viewportWidth/2 * right + v * viewportHeight/2 * up)
                    };
                    
                    // b. Szene nach Treffern durchsuchen (FindClosestHitPoint)
                    HitInfo closestHit = new HitInfo { DidHit = false, Distance = float.MaxValue };
                    foreach(var sphere in scene.Spheres)
                    {
                        HitInfo currentHit = sphere.Intersect(ray);
                        if(currentHit.DidHit && currentHit.Distance < closestHit.Distance)
                        {
                            closestHit = currentHit;
                        }
                    }

                    // c. Farbe berechnen (ComputeColor)
                    Vector3 linearColor = closestHit.DidHit ? closestHit.Material.Color : backgroundColor;

                    // d. Pixel in den Puffer schreiben
                    int idx = y * stride + x * 4;
                    WriteBgra(pixels, idx, linearColor);
                }
            }

            _wb.Lock();
            _wb.WritePixels(new Int32Rect(0, 0, W, H), pixels, stride, 0);
            _wb.AddDirtyRect(new Int32Rect(0, 0, W, H));
            _wb.Unlock();
        }

        #region Hilfsfunktionen für Farbe und Pixel
        static byte ToSrgb8(float linear)
        {
            if (linear <= 0f) return 0;
            if (linear >= 1f) return 255;
            float srgb = linear <= 0.0031308f ? 12.92f * linear : 1.055f * MathF.Pow(linear, 1f / 2.4f) - 0.055f;
            return (byte)Math.Clamp((int)MathF.Round(srgb * 255f), 0, 255);
        }

        static void WriteBgra(byte[] buf, int idx, Vector3 linearRgb)
        {
            buf[idx + 0] = ToSrgb8(linearRgb.Z); // B
            buf[idx + 1] = ToSrgb8(linearRgb.Y); // G
            buf[idx + 2] = ToSrgb8(linearRgb.X); // R
            buf[idx + 3] = 255; // A
        }
        #endregion
    }
}*/

using System;
using System.Collections.Generic;
using System.Numerics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Lab2
{
    // -------------------- RAY TRACING DATA --------------------

    /// Ray: E + λ d   (λ ≥ 0)
    public struct Ray
    {
        public Vector3 E;   // eye / origin
        public Vector3 d;   // direction (not necessarily normalized when created)
    }

    /// Simple material: linear RGB color
    public struct Material
    {
        public Vector3 Color;
    }

    /// Hit record
    public struct HitInfo
    {
        public bool DidHit;
        public float λ;             // distance parameter along the ray
        public Vector3 H;           // hit point
        public Vector3 n;           // unit surface normal at H
        public Material Material;   // material of the intersected primitive
    }

    /// Sphere with center C and radius r
    public class Sphere
    {
        public Vector3 C;
        public float r;
        public Material Material;

        /// Intersect ray with sphere using the quadratic from the notes.
        /// Solve: || (E + λ d) - C ||^2 = r^2  -> a λ^2 + b λ + c = 0
        public HitInfo Intersect(Ray ray)
        {
            Vector3 OC = ray.E - C;                     // O - C  (notes)
            float a = Vector3.Dot(ray.d, ray.d);        // d·d
            float b = 2.0f * Vector3.Dot(OC, ray.d);    // 2(OC·d)
            float c = Vector3.Dot(OC, OC) - r * r;      // ||OC||^2 - r^2

            float Δ = b * b - 4.0f * a * c;             // discriminant
            if (Δ < 0.0f)
                return new HitInfo { DidHit = false };   // no real roots → no hit

            float sqrtΔ = MathF.Sqrt(Δ);
            float λ0 = (-b - sqrtΔ) / (2.0f * a);          // near/root with minus
            float λ1 = (-b + sqrtΔ) / (2.0f * a);          // far/root with plus

            // We want the nearest positive λ (in front of the eye).
            const float EPS = 1e-3f;
            float λhit = λ0;
            if (λhit < EPS)
            {
                λhit = λ1;
                if (λhit < EPS)
                    return new HitInfo { DidHit = false };
            }

            Vector3 H = ray.E + λhit * ray.d;           // H = E + λ d
            Vector3 n = Vector3.Normalize(H - C);       // n = (H - C)/||H - C||

            return new HitInfo
            {
                DidHit = true,
                λ = λhit,
                H = H,
                n = n,
                Material = this.Material
            };
        }
    }

    /// Scene = just a list of spheres for now
    public class Scene
    {
        public List<Sphere> Spheres = new List<Sphere>();
    }

    // -------------------- WPF WINDOW / RENDERER --------------------

    public partial class MainWindow : Window
    {
        const int W = 512, H = 512;
        private WriteableBitmap _wb;

        public MainWindow()
        {
            InitializeComponent();
            var img = new Image();
            Content = img;
            _wb = new WriteableBitmap(W, H, 96, 96, PixelFormats.Bgra32, null);
            img.Source = _wb;

            RenderScene();
        }

        // ---- Camera helpers (exactly as in your notes) ----
        // f = normalize(lookAt - E)
        // r = normalize( f × upWorld )
        // u = r × f
        // FOV α defines viewport via tan(α/2)
        private static (Vector3 f, Vector3 r, Vector3 u, float vw, float vh) BuildCameraBasis(
            Vector3 E, Vector3 lookAt, float fovDegrees, float aspect)
        {
            Vector3 f = Vector3.Normalize(lookAt - E);
            // Choose world-up; handle degenerate case (if f parallel to up) in a simple way
            Vector3 upWorld = new Vector3(0, 1, 0);
            if (MathF.Abs(Vector3.Dot(f, upWorld)) > 0.999f) upWorld = new Vector3(0, 0, 1);
            
            
            Vector3 r = Vector3.Normalize(Vector3.Cross(upWorld, f)); // notice operands swapped
            Vector3 u = Vector3.Cross(f, r);


            float α = MathF.PI * fovDegrees / 180.0f;
            float vh = 2.0f * MathF.Tan(α * 0.5f);  // full viewport height at unit distance
            float vw = vh * aspect;                 // full viewport width

            return (f, r, u, vw, vh);
        }

        // CreateEyeRay for pixel (x,y) using your β and ω notation:
        // β = tan(α/2) * x',  ω = tan(α/2) * y',  with x',y' ∈ [-1,1]
        // Then d = f + β r + ω u  (and we normalize d for consistent distance units)
        private static Ray CreateEyeRay(int x, int y, int W, int H,
                                        Vector3 E, (Vector3 f, Vector3 r, Vector3 u, float vw, float vh) cam)
        {
            // map pixel center to NDC in [-1,1]
            float xNorm = (x / (float)(W - 1)) * 2.0f - 1.0f;        // → left=-1, right=+1
            float yNorm = ((H - 1 - y) / (float)(H - 1)) * 2.0f - 1.0f; // flip Y so up=+1

            // β, ω scale by half-viewport (your notes draw half-extents)
            float β = xNorm * (cam.vw * 0.5f);
            float ω = yNorm * (cam.vh * 0.5f);

            Vector3 d = cam.f + β * cam.r + ω * cam.u;
            d = Vector3.Normalize(d);

            return new Ray { E = E, d = d };
        }

        // ---- Render ----
        void RenderScene()
        {
            // 1) Scene (same setup you used)
            var scene = new Scene();
            scene.Spheres.Add(new Sphere { C = new Vector3(-1001, 0, 0), r = 1000, Material = new Material { Color = new Vector3(0.8f, 0.1f, 0.1f) } }); // left wall
            scene.Spheres.Add(new Sphere { C = new Vector3( 1001, 0, 0), r = 1000, Material = new Material { Color = new Vector3(0.1f, 0.1f, 0.8f) } }); // right wall
            scene.Spheres.Add(new Sphere { C = new Vector3(0, 1001, 0),  r = 1000, Material = new Material { Color = new Vector3(0.8f, 0.8f, 0.8f) } }); // ceiling
            scene.Spheres.Add(new Sphere { C = new Vector3(0,-1001, 0),  r = 1000, Material = new Material { Color = new Vector3(0.6f, 0.6f, 0.6f) } }); // floor
            scene.Spheres.Add(new Sphere { C = new Vector3(0, 0, 1001),  r = 1000, Material = new Material { Color = new Vector3(0.6f, 0.6f, 0.6f) } }); // back wall

            scene.Spheres.Add(new Sphere { C = new Vector3(-0.6f, -0.7f, -0.6f), r = 0.3f, Material = new Material { Color = new Vector3(0.9f, 0.9f, 0.1f) } }); // yellow
            scene.Spheres.Add(new Sphere { C = new Vector3(0.3f, -0.4f, 0.3f),   r = 0.6f, Material = new Material { Color = new Vector3(0.1f, 0.9f, 0.9f) } }); // cyan

            // 2) Camera exactly like the notes
            Vector3 E = new Vector3(-0.9f, -0.5f, 0.9f);   // eye
            Vector3 lookAt = new Vector3(0, 0, 0);
            float fov = 110.0f;                            // α
            Vector3 background = new Vector3(0, 0, 0);

            float aspect = (float)W / H;
            var cam = BuildCameraBasis(E, lookAt, fov, aspect);

            int stride = _wb.BackBufferStride;
            byte[] pixels = new byte[stride * H];

            // 3) Loop pixels → generate eye ray → find closest hit → write color
            for (int y = 0; y < H; y++)
            {
                for (int x = 0; x < W; x++)
                {
                    Ray ray = CreateEyeRay(x, y, W, H, E, cam);

                    HitInfo closest = new HitInfo { DidHit = false, λ = float.MaxValue };
                    foreach (var s in scene.Spheres)
                    {
                        var hit = s.Intersect(ray);
                        if (hit.DidHit && hit.λ < closest.λ)
                            closest = hit;
                    }

                    Vector3 color = closest.DidHit ? closest.Material.Color : background;

                    int idx = y * stride + x * 4;
                    WriteBGRA(pixels, idx, color);
                }
            }

            _wb.Lock();
            _wb.WritePixels(new Int32Rect(0, 0, W, H), pixels, stride, 0);
            _wb.AddDirtyRect(new Int32Rect(0, 0, W, H));
            _wb.Unlock();
        }

        // -------------------- Color helpers --------------------
        static byte ToSrgb8(float linear)
        {
            if (linear <= 0f) return 0;
            if (linear >= 1f) return 255;
            float srgb = linear <= 0.0031308f
                ? 12.92f * linear
                : 1.055f * MathF.Pow(linear, 1f / 2.4f) - 0.055f;
            return (byte)Math.Clamp((int)MathF.Round(srgb * 255f), 0, 255);
        }

        static void WriteBGRA(byte[] buf, int idx, Vector3 linearRgb)
        {
            buf[idx + 0] = ToSrgb8(linearRgb.Z); // B
            buf[idx + 1] = ToSrgb8(linearRgb.Y); // G
            buf[idx + 2] = ToSrgb8(linearRgb.X); // R
            buf[idx + 3] = 255;                  // A
        }
    }
}
